// ignore: file_names
const String girlWithBox =
    "https://assets8.lottiefiles.com/packages/lf20_ycdtcb3u.json";

const String itemInCart =
    "https://assets1.lottiefiles.com/packages/lf20_ghetz8rv.json";

const String securePayment =
    "https://assets1.lottiefiles.com/packages/lf20_8ahymrjw.json";

const String packageTracking =
    "https://assets4.lottiefiles.com/packages/lf20_0aeuYFhzMg.json";

const String cartSlidingOnPhone =
    "https://assets7.lottiefiles.com/packages/lf20_5ngs2ksb.json";

const String shoppingPhoneSale =
    "https://assets7.lottiefiles.com/packages/lf20_vjrlq3tj.json";

const String registrationDone =
    "https://assets2.lottiefiles.com/private_files/lf30_3ghvm6sn.json";

const String manWalkingWithDog =
    "https://assets2.lottiefiles.com/packages/lf20_XRLjtE.json";

const String userSignUp =
    "https://assets2.lottiefiles.com/packages/lf20_0mohmgca.json";
