import 'package:flutter/material.dart';
import 'package:inshop/utils/colors.dart';

class authIcons extends StatelessWidget {
  final String innerImage;
  const authIcons({
    super.key,
    required this.innerImage,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100,
      height: 55,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(
        vertical: 9,
      ),
      decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
            width: 1,
          ),
          borderRadius: BorderRadius.circular(12)),
      child: Image.asset(innerImage),
    );
  }
}

class CircleImageInsideWithOutlineCircleWithBottomText extends StatelessWidget {
  final String innerImage;
  final String bottomText;
  final Color backgroundColor;
  const CircleImageInsideWithOutlineCircleWithBottomText({
    super.key,
    required this.innerImage,
    this.bottomText = "bottom text",
    this.backgroundColor = navbarSelectedItemBackground,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            border: Border.all(
              color: Color.fromARGB(156, 158, 158, 158),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(55),
          ),
          child: Container(
            margin: EdgeInsets.all(2),
            width: 60,
            height: 60,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(
              vertical: 9,
            ),
            decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: BorderRadius.circular(55),
            ),
            child: Image.asset(
              innerImage,
              height: 30,
            ),
          ),
        ),
        SizedBox(
          height: 8,
        ),
        Text(
          bottomText,
          style: TextStyle(
            color: Colors.black,
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}
