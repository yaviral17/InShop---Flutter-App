String onBoardScreen1Title = "Find the item you've\nbeen looking for";
String onBoardScreen1Disc =
    "Here you'll see rich varities of goods, carefully classified for seamless browsing experience.";
String onBoardScreen1Footer = " ";

String onBoardScreen2Title = "Get those shopping\nbags filled";
String onBoardScreen2Disc =
    "Add any item you want to your cart, or save it on your wishlist, so you don't miss it in your future purchases.";
String onBoardScreen2Footer = " ";

String onBoardScreen3Title = "Fast & secure\npayment";
String onBoardScreen3Disc =
    "here are many payment options avilable for your ease.";
String onBoardScreen3Footer = ' ';

String onBoardScreen4Title = "Package tracking";
String onBoardScreen4Disc =
    "In particular,InShop can pack your orders, and help you seamless manage your shipments.";
String onBoardScreen4Footer = ' ';

String onBoardScreen5Title = "Get those shopping\nbags filled";
String onBoardScreen5Disc =
    "Add any item you want to your cart, or save it on your wishlist, so you don't miss it in your future purchases.";
String onBoardScreen5Footer = ' ';
