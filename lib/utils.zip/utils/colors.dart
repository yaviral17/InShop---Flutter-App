import 'package:flutter/material.dart';

const Color navbarSelected = Color.fromARGB(255, 22, 123, 206);
const Color navbarSelectedItemBackground = Color.fromARGB(64, 33, 149, 243);
const Color navbarNotSelected = Colors.grey;
const Color textFieldBackgroundLightGrey = Color.fromARGB(103, 215, 215, 215);
